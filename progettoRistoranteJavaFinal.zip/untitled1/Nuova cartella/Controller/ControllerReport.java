package Controller;
import java.util.List;
import java.util.ArrayList;
public class ControllerReport {
    public DTO.DTOIngrediente GeneraReport() {


        Entity.EntityMagazzino magazzino = Entity.EntityMagazzino.getInstance();
            return magazzino.GeneraReport(); // 11.1
        }
    }


package Controller;
import Entity.*;
import database.*;

import java.util.List;
import java.util.Map;

public class mainprova6 {
    public static void main(String[] args) {
        // Carica tutte le entità necessarie
        System.out.println("=== Caricamento Pietanze ===");
        List<EntityPietanza> pietanze = DAOPietanza.getPietanze();
        for (EntityPietanza p : pietanze) {
            System.out.println("Pietanza: " + p.getNome() + ", Prezzo: " + p.getPrezzo());
        }

        System.out.println("\n=== Caricamento Menu Fissi ===");
        List<EntityMenuFisso> menuFissi = DAOMenuFisso.getMenuFissi();
        for (EntityMenuFisso mf : menuFissi) {
            System.out.println("Menu Fisso: " + mf.getNome() + ", Prezzo: " + mf.getPrezzo());
            for (EntityPietanza p : mf.getPortate()) {
                System.out.println("  - Pietanza: " + p.getNome());
            }
        }

        System.out.println("\n=== Caricamento Menu ===");
        DAOMenu.caricaMenu();

        EntityMenu menu = EntityMenu.getInstance();
        Map<Integer, EntityOrdinabile> ordinabili = menu.getMappaOrdinabili();

        for (Map.Entry<Integer, EntityOrdinabile> entry : ordinabili.entrySet()) {
            int id = entry.getKey();
            EntityOrdinabile ord = entry.getValue();
            System.out.println("ID: " + id + " -> Ordinabile: " + ord.getNome() +
                    " (" + ord.getClass().getSimpleName() + ")");
        }

        System.out.println("\n=== Fine Caricamento ===");
    }
}
package Controller;

import Entity.EntityMenuFisso;
import Entity.EntityPietanza;
import database.DAOMenuFisso;

import java.util.List;

public class mainprova5 {
    public static void main(String[] args) {
        // Caricamento di tutti i menu fissi dal database
        List<EntityMenuFisso> listaMenuFissi = DAOMenuFisso.getMenuFissi();

        System.out.println("---- MENU FISSI CARICATI DAL DB ----");
        for (EntityMenuFisso mf : listaMenuFissi) {
            System.out.println("Menu: " + mf.getNome() + " - Prezzo: " + mf.getPrezzo());
            System.out.println("Pietanze incluse:");
            for (EntityPietanza p : mf.getPortate()) {
                System.out.println("  • " + p.getNome());
            }
            System.out.println();
        }
    }
}
package Controller;

public class mainprova3
{ public static void main(String[] args) {

    Entity.EntityMenuFisso mf = new Entity.EntityMenuFisso("Menu Pizza Classico");
    System.out.println(mf.getNome() + " - €" + mf.getPrezzo());
    for (Entity.EntityPietanza p : mf.getPortate()) {
        System.out.println(" - " + p.getNome());
    }

}
}

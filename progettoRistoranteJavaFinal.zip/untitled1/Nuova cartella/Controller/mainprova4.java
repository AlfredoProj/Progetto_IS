package Controller;
import Entity.EntityPietanza;
import database.DAOPietanza;

import java.util.List;

public class mainprova4 {
    public static void main(String[] args) {
        // Caricamento di tutte le pietanze dal database
        List<EntityPietanza> listaPietanze = DAOPietanza.getPietanze();

        System.out.println("---- PIETANZE CARICATE DAL DB ----");
        for (EntityPietanza p : listaPietanze) {
            System.out.println("Pietanza: " + p.getNome() + ", Prezzo: " + p.getPrezzo());
        }
    }
}

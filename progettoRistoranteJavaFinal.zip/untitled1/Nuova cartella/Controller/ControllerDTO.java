package Controller;
import Entity.EntityOrdinabile;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
public class ControllerDTO {
    public List<DTO.DTOOrdinabile> RichiediMenu() {
        Entity.EntityMenu menu = Entity.EntityMenu.getInstance();
        List<DTO.DTOOrdinabile> dtoList = new ArrayList<>();

        for (int id : menu.getMappaOrdinabili().keySet()) {
            Entity.EntityOrdinabile ord = menu.getMappaOrdinabili().get(id);
            DTO.DTOOrdinabile dto = new DTO.DTOOrdinabile();
            dto.setID(id);
            dto.setNome(ord.getNome());
            dtoList.add(dto);
        }

        return dtoList;
    }
    public List<DTO.DTORiepilogo> OttieniElementiRiepilogo(int numero_tavolo) {
        List<DTO.DTORiepilogo> listaDTO = new ArrayList<>();

        Entity.EntityRistorante ristorante = Entity.EntityRistorante.getInstance();
        Entity.EntityTavolo tavolo = ristorante.TrovaTavolo(numero_tavolo);

        if (tavolo != null && tavolo.getOrdine() != null) {
            Entity.EntityOrdine ordine = tavolo.getOrdine();
            Map<EntityOrdinabile, Integer> elementi = ordine.getElementi_ordine();
            Map<Integer, EntityOrdinabile> mappa = Entity.EntityMenu.getInstance().getMappaOrdinabili();

            for (Map.Entry<EntityOrdinabile, Integer> entry : elementi.entrySet()) {
                DTO.DTORiepilogo dto = new DTO.DTORiepilogo();

                // Set nome e quantità
                dto.setNome(entry.getKey().getNome());
                dto.setQuantita(entry.getValue());

                // Ricerca e set ID corrispondente
                for (Map.Entry<Integer, EntityOrdinabile> e : mappa.entrySet()) {
                    if (e.getValue().equals(entry.getKey())) {
                        dto.setId(e.getKey());
                        break;
                    }
                }

                listaDTO.add(dto);
            }
        }

        return listaDTO;
    }
}

package Controller;

import Entity.EntityPietanza;

import java.util.List;

public class mainprova2 {

    public static void main(String[] args) {
        Entity.EntityPietanza p = new Entity.EntityPietanza("Pizza Margherita");
        System.out.println(p.getNome() + " - €" + p.getPrezzo());


    }
}

package Controller;

public class ControllerCassiere {

    public boolean ValidaInput(int numero, int coperti) {
        return coperti > 0;
    }

    public double CalcolaConto(int numeroTavolo) {
        Entity.EntityRistorante ristorante = Entity.EntityRistorante.getInstance();
        Entity.EntityTavolo tavolo = ristorante.TrovaTavolo(numeroTavolo);
        Entity.EntityOrdine ordine = tavolo.getOrdine();

        if (ordine == null) return -1;

        double prezzo = tavolo.CalcolaContoTot(ordine);  // chiama internamente CalcolaPrezzo + SommaCoperto

        // Liberazioni post pagamento
        ordine.LiberaOrdine();
        tavolo.LiberaTavolo();
        Entity.EntityElencoOrdini.getInstance().RimuoviOrdine(ordine);


        return prezzo;
    }
}
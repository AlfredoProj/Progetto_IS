package Controller;

import Boundary.BoundaryReport;
import java.util.Map;

public class mainprova {
    public static void main(String[] args) {
        Entity.EntityMagazzino magazzino = Entity.EntityMagazzino.getInstance();

        System.out.println("==== SCORTE ATTUALI ====");
        for (Map.Entry<Entity.EntityIngrediente, Integer> entry : magazzino.getLista_ingredienti().entrySet()) {
            String nome = entry.getKey().getNome();
            int quantita = entry.getValue();
            System.out.println("Ingrediente: " + nome + " - Quantità disponibile: " + quantita);
        }

        // Test: generazione report su soglie basse
        System.out.println("\n==== REPORT INGREDIENTI SOTTO SOGLIA ====");
        System.out.println(magazzino.GeneraReport().getLista());}}

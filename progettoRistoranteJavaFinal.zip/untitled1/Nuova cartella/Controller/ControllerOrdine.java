package Controller;
import java.util.List;
public class ControllerOrdine {
    public void ConfermaOrdine(int numeroTavolo) {
        Entity.EntityRistorante ristorante = Entity.EntityRistorante.getInstance();
        Entity.EntityTavolo tavolo = ristorante.TrovaTavolo(numeroTavolo);

        if (tavolo != null && tavolo.getOrdine() != null) {
            tavolo.getOrdine().ConfermaOrdine(); // Imposta stato e salva nel DB
            Entity.EntityElencoOrdini elenco = Entity.EntityElencoOrdini.getInstance();
            elenco.AggiungiOrdine(tavolo.getOrdine());
        }
    }


    public String ValidaInput(int numero_tavolo, int numero_coperti) {
        Entity.EntityRistorante ristorante = Entity.EntityRistorante.getInstance();
        Entity.EntityTavolo tavolo = ristorante.TrovaTavolo(numero_tavolo);

        if (tavolo == null) {
            return "Errore: tavolo non trovato.";
        }

        if (!ControllaCoperti(numero_coperti,tavolo.getPostiMax())) {
            return "Errore: numero coperti non valido.";
        }

        tavolo.setNumero_coperti(numero_coperti);
        tavolo.aggiornaSuDB();

        return "OK";
    }
    private boolean ControllaCoperti(int coperti, int posti_max) {
        return coperti > 0 && coperti <= posti_max;
    }
    public void DecrementaElem(int id, int numeroTavolo) {
        Entity.EntityOrdinabile ordinabile = Entity.EntityMenu.getInstance().getMappaOrdinabili().get(id);
        if (ordinabile == null) return;

        Entity.EntityRistorante ristorante = Entity.EntityRistorante.getInstance();
        Entity.EntityTavolo tavolo = ristorante.TrovaTavolo(numeroTavolo);
        if (tavolo != null && tavolo.getOrdine() != null) {
            tavolo.getOrdine().DecrementaQuantita(ordinabile);

            // Ritorna scorte al magazzino
            if (ordinabile instanceof Entity.EntityPietanza) {
                List<Entity.EntityDoseIngrediente> dosi = ((Entity.EntityPietanza) ordinabile).OttieniDosi();
                Entity.EntityMagazzino.getInstance().RitornaScorta(dosi);

            } else if (ordinabile instanceof Entity.EntityMenuFisso) {
                List<Entity.EntityPietanza> portate = ((Entity.EntityMenuFisso) ordinabile).getPortate();
                for (Entity.EntityPietanza pietanza : portate) {
                    List<Entity.EntityDoseIngrediente> dosi = pietanza.OttieniDosi();
                    Entity.EntityMagazzino.getInstance().RitornaScorta(dosi);
                }
            }
        }
    }

    public void GeneraOrdine(int numeroTavolo) {
        Entity.EntityTavolo tavolo = Entity.EntityRistorante.getInstance().TrovaTavolo(numeroTavolo);
        if (tavolo != null) {
            tavolo.GeneraOrdine();
        }
    }
    public String AggiungiOrdinabile(int id, int numeroTavolo) {
        Entity.EntityRistorante ristorante = Entity.EntityRistorante.getInstance();
        Entity.EntityTavolo tavolo = ristorante.TrovaTavolo(numeroTavolo);

        if (tavolo == null) return "Errore: tavolo non trovato.";
        Entity.EntityOrdine ordine = tavolo.getOrdine();
        if (ordine == null) return "Errore: nessun ordine associato al tavolo.";

        Entity.EntityOrdinabile ordinabile = Entity.EntityMenu.getInstance().OttieniOrdinabile(id);
        if (ordinabile == null) return "Errore: ordinabile non trovato.";

        if (ordinabile instanceof Entity.EntityPietanza) {
            List<Entity.EntityDoseIngrediente> dosi = ((Entity.EntityPietanza) ordinabile).OttieniDosi();
            boolean prenotato = Entity.EntityMagazzino.getInstance().PrenotaScorta(dosi);
            if (!prenotato) return "Errore: scorte insufficienti.";

        } else if (ordinabile instanceof Entity.EntityMenuFisso) {
            List<Entity.EntityPietanza> portate = ((Entity.EntityMenuFisso) ordinabile).getPortate();
            for (Entity.EntityPietanza p : portate) {
                List<Entity.EntityDoseIngrediente> dosi = p.OttieniDosi();
                boolean prenotato = Entity.EntityMagazzino.getInstance().PrenotaScorta(dosi);
                if (!prenotato) return "Errore: scorte insufficienti per una portata del menu.";
            }
        }

        ordine.AddToOrder(ordinabile);
        return "Ordinabile aggiunto correttamente.";
    }

}
package Entity;

public interface EntityOrdinabile {
    public String getNome();
    public void setNome(String nome);
    public float getPrezzo();
    public void setPrezzo(float prezzo);

}

package Entity;

public class EntityIngrediente {
    private String nome;
    private int quantita_soglia;

    public EntityIngrediente(String nome, int soglia) {
        this.nome = nome;
        this.quantita_soglia = soglia;
    }

    public boolean VerificaQuantitaReport(int quantita_scorta) {
        return quantita_scorta < quantita_soglia;
    }

    public String getNome() { return nome; }
    public int getQuantitaSoglia() { return quantita_soglia; }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setQuantita_soglia(int quantita_soglia) {
        this.quantita_soglia = quantita_soglia;
    }
}

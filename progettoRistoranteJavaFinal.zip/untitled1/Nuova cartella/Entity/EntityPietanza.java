package Entity;
import java.util.List;

public class EntityPietanza implements EntityOrdinabile{
    private String nome;
    private float prezzo;
    private EntityRicetta ricetta;

    public EntityPietanza(String nome, float prezzo, EntityRicetta ricetta) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.ricetta = ricetta;
    }

    public EntityPietanza(String nome) {
        database.DAOPietanza dao = new database.DAOPietanza(nome);
        this.nome = dao.getNome();
        this.prezzo = dao.getPrezzo();
        this.ricetta = dao.getRicetta();
    }
    public List<EntityDoseIngrediente> OttieniDosi() {
        return ricetta.getDosi();
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public float getPrezzo() { return prezzo; }
    public void setPrezzo(float prezzo) { this.prezzo = prezzo;}


}

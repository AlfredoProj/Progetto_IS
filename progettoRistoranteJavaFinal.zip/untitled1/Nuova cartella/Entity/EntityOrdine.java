package Entity;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;
public class EntityOrdine {
    private EntityTavolo tavolo;
    private int stato;
    private Map<EntityOrdinabile, Integer> elementi_ordine = new HashMap<>();

    public EntityOrdine(EntityTavolo tavolo) {
        this.tavolo = tavolo;
        this.stato = 0;
    }

    public void AddToOrder(EntityOrdinabile elem) {
        elementi_ordine.put(elem, elementi_ordine.getOrDefault(elem, 0) + 1);
    }

    public double CalcolaPrezzo() {
        return elementi_ordine.entrySet().stream().mapToDouble(e -> e.getKey().getPrezzo() * e.getValue()).sum();
    }

    public void ConfermaOrdine() {
        this.stato = 1;

        // Inserimento nel DB tramite DAO
        database.DAOOrdine dao = new database.DAOOrdine(this);
        dao.createOrdine();  // crea record nel DB
    }

    public void DecrementaQuantita(EntityOrdinabile elem) {
        elementi_ordine.computeIfPresent(elem, (k, v) -> v > 1 ? v - 1 : null);
    /*Controlla se elem è presente nella mappa elementi_ordine.

Se presente, allora:

Se la quantità (cioè il valore associato a elem) è maggiore di 1:

La decrementa di 1.

Se la quantità è esattamente 1:

Ritorna null, quindi rimuove l'entry dalla mappa.*/
    }
    public List<DTO.DTORiepilogo> GeneraRiepilogo() {
        List<DTO.DTORiepilogo> riepilogo = new ArrayList<>();
        for (Map.Entry<EntityOrdinabile, Integer> entry : elementi_ordine.entrySet()) {
            DTO.DTORiepilogo dto = new DTO.DTORiepilogo();
            dto.setNome(entry.getKey().getNome());
            dto.setQuantita(entry.getValue());
            riepilogo.add(dto);
        }
        return riepilogo;
    }

    public EntityTavolo getTavolo() {
        return tavolo;
    }

    public int getStato() {
        return stato;
    }

    public Map<EntityOrdinabile, Integer> getElementi_ordine() {
        return elementi_ordine;
    }
    public void LiberaOrdine() {
        database.DAOOrdine dao = new database.DAOOrdine(this);
        dao.deleteOrdine();   // elimina dal DB
    }

}

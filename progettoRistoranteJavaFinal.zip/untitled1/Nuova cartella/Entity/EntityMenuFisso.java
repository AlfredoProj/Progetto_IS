package Entity;
import java.util.List;
public class EntityMenuFisso implements EntityOrdinabile {
    private String nome;
    private float prezzo;
    private List<EntityPietanza> portate;

    public EntityMenuFisso(String nome, float prezzo, List<EntityPietanza> portate) {
        this.nome = nome;
        this.prezzo = prezzo;
        this.portate = portate;
    }
    public EntityMenuFisso(String nome) {
        database.DAOMenuFisso dao = new database.DAOMenuFisso(nome);
        this.nome = dao.getNome();
        this.prezzo = dao.getPrezzo();
        this.portate = dao.getPortate();
    }

    public boolean OttieniDosiTotali() {
        // Dummy logic, implement real one if needed
        return !portate.isEmpty();
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public float getPrezzo() { return prezzo; }
    public void setPrezzo(float prezzo) { this.prezzo = prezzo; }
    public List<EntityPietanza> getPortate() { return portate; }

}

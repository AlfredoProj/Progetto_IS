package Entity;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class EntityMagazzino {

    private Map<EntityIngrediente, Integer> lista_ingredienti = new HashMap<>();
    private static EntityMagazzino instance = null;

    private EntityMagazzino() {}

    public static EntityMagazzino getInstance() {
        if (instance == null) {
            instance = new EntityMagazzino();
            database.DAOMagazzino dao = new database.DAOMagazzino();
            instance.lista_ingredienti = dao.getScorte();
        }
        return instance;
    }

    public boolean PrenotaScorta(List<EntityDoseIngrediente> dosi) {
        if (!ControlloDisponibilità(dosi)) {
            return false;
        }

        for (EntityDoseIngrediente dose : dosi) {
            DecrementaScorta(dose);
        }

        return true;
    }


    public DTO.DTOIngrediente GeneraReport() {
        List<String> nomiIngredienti = new ArrayList<>();
        for (Map.Entry<EntityIngrediente, Integer> entry : lista_ingredienti.entrySet()) {
            if (VerificaQuantitaReport(entry.getValue())) {
                nomiIngredienti.add(entry.getKey().getNome());
            }
        }
        DTO.DTOIngrediente dto = new DTO.DTOIngrediente();
        dto.setLista(nomiIngredienti);
        return dto;
    }

    private boolean VerificaQuantitaReport(int quantita) {
        return quantita < 10;
    }
    private void DecrementaScorta(EntityDoseIngrediente dose) {
        EntityIngrediente ingr = dose.getIngrediente();
        int quantita = dose.getQuantita();
        int disponibile = lista_ingredienti.getOrDefault(ingr, 0);

        // Aggiorna mappa locale
        lista_ingredienti.put(ingr, disponibile - quantita);

        // Aggiorna nel database
        database.DAOMagazzino dao = new database.DAOMagazzino();
        dao.aggiornaSingolaScorta(ingr, disponibile - quantita);
    }
    public boolean ControlloDisponibilità(List<EntityDoseIngrediente> dosi) {
        for (EntityDoseIngrediente dose : dosi) {
            int disponibile = lista_ingredienti.getOrDefault(dose.getIngrediente(), 0);
            if (disponibile < dose.getQuantita()) {
                return false;
            }
        }
        return true;
    }//davedere
    public void RitornaScorta(List<EntityDoseIngrediente> dosi) {
        for (EntityDoseIngrediente dose : dosi) {
            EntityIngrediente ingr = dose.getIngrediente();
            int quantita = dose.getQuantita();
            int disponibile = lista_ingredienti.getOrDefault(ingr, 0);
            lista_ingredienti.put(ingr, disponibile + quantita);

            // aggiorna nel database
            database.DAOMagazzino dao = new database.DAOMagazzino();
            dao.aggiornaSingolaScorta(ingr, disponibile + quantita);
        }
    }

    public Map<EntityIngrediente, Integer> getLista_ingredienti() {
        return lista_ingredienti;
    }
}

package Entity;
import java.util.ArrayList;
import java.util.List;

public class EntityElencoOrdini {
    private static EntityElencoOrdini instance = null;
    private List<EntityOrdine> ordini = new ArrayList<>();

    private EntityElencoOrdini() {}

    public static EntityElencoOrdini getInstance() {
        if (instance == null) instance = new EntityElencoOrdini();
        return instance;
    }

    public void AggiungiOrdine(EntityOrdine ordine) {
        ordini.add(ordine);
    }

    public void RimuoviOrdine(EntityOrdine ordine) {
        ordini.remove(ordine);
    }

   /* public EntityOrdine TrovaOrdine(int num_tavolo) {
NON UTILIZZATO
    }

    public void VisualizzaElenco() {
NON UTILIZZATO
    }*/
}
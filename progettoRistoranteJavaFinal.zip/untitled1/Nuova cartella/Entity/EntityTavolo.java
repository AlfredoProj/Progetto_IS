package Entity;

import database.DAOTavolo;

public class EntityTavolo {
private int numero;
private int postiMax;
private int numero_coperti=0;
private EntityOrdine ordine=null;

public EntityTavolo(int numero) {
    //accesso al db
    database.DAOTavolo tavolo = new DAOTavolo(numero);
    this.postiMax=tavolo.getPostiMax();
    this.numero=numero;


}

public EntityTavolo(DAOTavolo tavolo){
//potrebbe capitare che ho già l oggetto dao riempito e devo solo copiarlo nell entity, ma di fatto nn accede al db
    this.numero=tavolo.getNumero();
    this.postiMax= tavolo.getPostiMax();



}
    @Override
    public String toString(){
        return "EntityTavolo [numero=" + numero + ",posti massimi=" + postiMax + "]";
    }

    public int getNumero() {
        return numero;
    }

    public int getPostiMax() {
        return postiMax;
    }

    public int getNumero_coperti() {
        return numero_coperti;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setPostiMax(int postiMax) {
        this.postiMax = postiMax;
    }

    public void setNumero_coperti(int numero_coperti) {
        this.numero_coperti = numero_coperti;
    }

    public void GeneraOrdine() {
        this.ordine = new EntityOrdine(this);
    }

    public double CalcolaContoTot(EntityOrdine ordine){
        double parziale = ordine.CalcolaPrezzo();
        return SommaCoperto(parziale);
    }
    public double SommaCoperto(double provvisorio){
        return provvisorio + numero_coperti * 2.0;

    }
    public void LiberaTavolo() {
        // 1. Libera ordine (ma non esegue più delete!)
        this.ordine = null;

        // 2. Azzerare coperti e aggiornare DB
        this.numero_coperti = 0;
        aggiornaSuDB(); // chiama DAOTavolo.updateCoperti(0)
    }

    public EntityOrdine getOrdine() {
        return ordine;
    }
    public void aggiornaSuDB() {
        DAOTavolo dao = new DAOTavolo(this.numero);
        dao.updateCoperti(this.numero_coperti);
    }
}

package Entity;
import java.util.List;

public class EntityRicetta {
    private List<EntityDoseIngrediente> dosi;

    public EntityRicetta(List<EntityDoseIngrediente> dosi) {
        this.dosi = dosi;
    }

    public List<EntityDoseIngrediente> getDosi() {
        return dosi;
    }
}

package Entity;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class EntityMenu {
    private List<EntityOrdinabile> lista_ordinabili;
    private Map<Integer, EntityOrdinabile> mappa_ordinabili = new HashMap<>();
    private static EntityMenu instance = null;

    private EntityMenu() {
        database.DAOMenu.caricaMenu();  // carica automaticamente il menu
    }

    public static EntityMenu getInstance() {
        if (instance == null) instance = new EntityMenu();
        return instance;
    }

    /*public void RichiediMenu() {
        // logica generazione
    }/*/

    public EntityOrdinabile OttieniOrdinabile(int ID) {
        return mappa_ordinabili.get(ID);
    }

    public List<EntityOrdinabile> getLista_ordinabili() {
        return lista_ordinabili;
    }
    public List<DTO.DTOOrdinabile> RichiediMenu(){

            List<DTO.DTOOrdinabile> dtoList = new ArrayList<>();
            for (int id : mappa_ordinabili.keySet()) {
                EntityOrdinabile ord = mappa_ordinabili.get(id);
                DTO.DTOOrdinabile dto = new DTO.DTOOrdinabile();
                dto.setID(id);
                dto.setNome(ord.getNome());
                dtoList.add(dto);
            }
            return dtoList;
        }
    public Map<Integer, EntityOrdinabile> getMappaOrdinabili() {
        return this.mappa_ordinabili;
    }

    public void setListaOrdinabili(List<EntityOrdinabile> lista) {
        this.lista_ordinabili = lista;
    }

    public void setMappa_ordinabili(Map<Integer, EntityOrdinabile> mappa_ordinabili) {
        this.mappa_ordinabili = mappa_ordinabili;
    }
}

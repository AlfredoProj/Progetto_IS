/*
package database;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Entity.*;



    public class DAOMenu {
        public static void caricaMenu() {
            try {
                String query = "SELECT id, Pietanza_id, MenuFisso_id FROM Menu";
                ResultSet rs = DBConnectionManager.selectQuery(query);

                EntityMenu menu = EntityMenu.getInstance();
                Map<Integer, EntityOrdinabile> mappa = menu.getMappaOrdinabili();
                List<EntityOrdinabile> lista = new ArrayList<>();

                // Recupero entità già caricate
                List<EntityPietanza> tutteLePietanze = DAOPietanza.getPietanze();
                List<EntityMenuFisso> tuttiIMenuFissi = DAOMenuFisso.getMenuFissi();

                while (rs.next()) {
                    int id = rs.getInt("id");
                    Integer idPietanza = rs.getObject("Pietanza_id") != null ? rs.getInt("Pietanza_id") : null;
                    Integer idMenuFisso = rs.getObject("MenuFisso_id") != null ? rs.getInt("MenuFisso_id") : null;

                    EntityOrdinabile ordinabile = null;

                    if (idPietanza != null) {
                        // Prendi il nome della pietanza
                        String queryPietanza = "SELECT nome FROM Pietanza WHERE id = " + idPietanza;
                        ResultSet rsP = DBConnectionManager.selectQuery(queryPietanza);
                        if (rsP.next()) {
                            String nomeP = rsP.getString("nome");
                            // Cerca tra le pietanze precaricate
                            for (EntityPietanza p : tutteLePietanze) {
                                if (p.getNome().equals(nomeP)) {
                                    ordinabile = p;
                                    break;
                                }
                            }
                        }
                    } else if (idMenuFisso != null) {
                        String queryMenuFisso = "SELECT nome FROM MenuFisso WHERE id = " + idMenuFisso;
                        ResultSet rsM = DBConnectionManager.selectQuery(queryMenuFisso);
                        if (rsM.next()) {
                            String nomeM = rsM.getString("nome");
                            for (EntityMenuFisso mf : tuttiIMenuFissi) {
                                if (mf.getNome().equals(nomeM)) {
                                    ordinabile = mf;
                                    break;
                                }
                            }
                        }
                    }

                    if (ordinabile != null) {
                        mappa.put(id, ordinabile);
                        lista.add(ordinabile);
                    }
                }

                // Associa lista completa
                menu.setListaOrdinabili(lista);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    */

package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import Entity.*;

public class DAOMenu {

    public static void caricaMenu() {
        EntityMenu menu = EntityMenu.getInstance();
        Map<Integer, EntityOrdinabile> mappa = menu.getMappaOrdinabili();
        List<EntityOrdinabile> lista = new ArrayList<>();

        // Entità già caricate in memoria
        List<EntityPietanza> tutteLePietanze = DAOPietanza.getPietanze();
        List<EntityMenuFisso> tuttiIMenuFissi = DAOMenuFisso.getMenuFissi();

        String queryMenu = "SELECT id, Pietanza_id, MenuFisso_id FROM Menu";

        try {
            DBConnectionManager.selectQueryClose(queryMenu, rs -> {
                try {
                    while (rs.next()) {
                        int id = rs.getInt("id");
                        Integer idPietanza = rs.getObject("Pietanza_id") != null ? rs.getInt("Pietanza_id") : null;
                        Integer idMenuFisso = rs.getObject("MenuFisso_id") != null ? rs.getInt("MenuFisso_id") : null;

                        EntityOrdinabile ordinabile = null;

                        if (idPietanza != null) {
                            String queryP = "SELECT nome FROM Pietanza WHERE id = " + idPietanza;
                            try (ResultSet rsP = DBConnectionManager.selectQuery(queryP)) {
                                if (rsP.next()) {
                                    String nomeP = rsP.getString("nome");
                                    for (EntityPietanza p : tutteLePietanze) {
                                        if (p.getNome().equals(nomeP)) {
                                            ordinabile = p;
                                            break;
                                        }
                                    }
                                }
                            }
                        } else if (idMenuFisso != null) {
                            String queryM = "SELECT nome FROM MenuFisso WHERE id = " + idMenuFisso;
                            try (ResultSet rsM = DBConnectionManager.selectQuery(queryM)) {
                                if (rsM.next()) {
                                    String nomeM = rsM.getString("nome");
                                    for (EntityMenuFisso mf : tuttiIMenuFissi) {
                                        if (mf.getNome().equals(nomeM)) {
                                            ordinabile = mf;
                                            break;
                                        }
                                    }
                                }
                            }
                        }

                        if (ordinabile != null) {
                            mappa.put(id, ordinabile);
                            lista.add(ordinabile);
                        }
                    }

                    // imposta la lista anche se non è obbligatorio (dipende dal tuo uso)
                    menu.setListaOrdinabili(lista);

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch ( SQLException e) {
            e.printStackTrace();
        }
    }
}



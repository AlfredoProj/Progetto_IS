package database;

import java.sql.ResultSet;
import java.sql.SQLException;


public class DAOTavolo {

    private int numero;
    private int postiMax;


public DAOTavolo(int num_tavolo){
    this.numero=num_tavolo;
    caricaDADB();

}
public void caricaDADB(){

    String query= "SELECT * FROM Tavolo WHERE numero='"+this.numero+"';";
    System.out.println(query);//per debug
    try{

        ResultSet rs = database.DBConnectionManager.selectQuery(query);

        if(rs.next()){//se ho un risultato

            this.setPostiMax(rs.getInt("postiMax"));


        }

    }catch (/* ClassNotFoundException | */SQLException e){

        e.printStackTrace();

    }


}
public int getPostiMax(){
    return postiMax;

}
public void setPostiMax(int num){
    this.postiMax=num;

}

public int getNumero(){
    return numero;

}
public void setNumero(int num){
    this.numero=num;


}
    public void updateCoperti(int nuoviCoperti) {
        String query = "UPDATE Tavolo SET numero_coperti = '" + nuoviCoperti + "' WHERE numero = '" + this.numero + "';";
        System.out.println(query); // debug
        try {
            database.DBConnectionManager.updateQuery(query);
        } catch (/*ClassNotFoundException |*/ SQLException e) {
            e.printStackTrace();
        }
    }

}

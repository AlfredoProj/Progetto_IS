package database;
import java.sql.ResultSet;
import java.sql.SQLException;

import Entity.EntityOrdine;

public class DAOOrdine {
    private EntityOrdine ordine;

    public DAOOrdine(EntityOrdine ordine) {
        this.ordine = ordine;
    }

    public void createOrdine() {
        String query = "INSERT INTO Ordine (numeroTavolo, stato) VALUES (" +
                ordine.getTavolo().getNumero() + ", " + ordine.getStato() + ");";
        try {
            DBConnectionManager.updateQuery(query);
        } catch (/*ClassNotFoundException | */SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteOrdine() {
        String query = "DELETE FROM Ordine WHERE numeroTavolo = " + ordine.getTavolo().getNumero() + ";";
        try {
            DBConnectionManager.updateQuery(query);           // 10.2.1
        } catch (/*ClassNotFoundException | */SQLException e) {
            e.printStackTrace();
        }
    }
}
package database;



import Entity.EntityIngrediente;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAOIngrediente {
    private EntityIngrediente ingrediente;

    private String nome;
    private int quantitaSoglia;

    public DAOIngrediente(int id) {
        caricaDaDB(id);
    }

    private void caricaDaDB(int id) {
        String query = "SELECT nome, quantita_soglia FROM Ingrediente WHERE id = '" + id + "';";
        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            if (rs.next()) {
                this.nome = rs.getString("nome");
                this.quantitaSoglia = rs.getInt("quantita_soglia");
            }
        } catch (/*ClassNotFoundException |*/ SQLException e) {
            e.printStackTrace();
        }
    }

    public EntityIngrediente getEntityIngrediente() {
        return new EntityIngrediente(nome, quantitaSoglia);
    }

    public DAOIngrediente(EntityIngrediente ingrediente) {
        this.ingrediente = ingrediente;
    }

    public void aggiornaQuantita(int nuovaQuantita) {
        String query = "UPDATE Ingrediente SET quantita = " + nuovaQuantita +
                " WHERE nome = '" + ingrediente.getNome() + "';";
        try {
            DBConnectionManager.updateQuery(query);
        } catch (/*ClassNotFoundException| */SQLException e) {
            e.printStackTrace();
        }
    }

}////errato
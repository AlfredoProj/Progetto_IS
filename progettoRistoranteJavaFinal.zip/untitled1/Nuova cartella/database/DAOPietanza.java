package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.*;
/*
public class DAOPietanza {
    private String nome;
    private float prezzo;
    private EntityRicetta ricetta;

    public DAOPietanza(String nomePietanza) {
        String query = "SELECT P.prezzo, D.quantita, D.Ingrediente_id " +
                "FROM Pietanza P " +
                "JOIN Ricetta R ON P.Ricetta_id = R.id " +
                "JOIN DoseIngrediente D ON R.DoseIngrediente_id = D.id " +
                "WHERE P.nome = '" + nomePietanza + "';";

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            List<EntityDoseIngrediente> dosi = new ArrayList<>();

            while (rs.next()) {
                this.nome = nomePietanza;
                this.prezzo = rs.getFloat("prezzo");

                int quantita = rs.getInt("quantita");
                int ingredienteId = rs.getInt("Ingrediente_id");

                DAOIngrediente daoIng = new DAOIngrediente(ingredienteId);
                EntityIngrediente ingrediente = daoIng.getEntityIngrediente();

                // Ricetta placeholder (verrà sovrascritta dopo)
                EntityRicetta ricettaFake = new EntityRicetta(null);
                EntityDoseIngrediente dose = new EntityDoseIngrediente(quantita, ricettaFake, ingrediente);
                dosi.add(dose);
            }

            // Imposta la ricetta reale
            this.ricetta = new EntityRicetta(dosi);

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    public String getNome() { return nome; }
    public float getPrezzo() { return prezzo; }
    public EntityRicetta getRicetta() { return ricetta; }
    public static List<EntityPietanza> getPietanze() {
        List<EntityPietanza> lista = new ArrayList<>();
        String query = "SELECT nome FROM Pietanza";
        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                String nome = rs.getString("nome");
                DAOPietanza dao = new DAOPietanza(nome);
                EntityPietanza p = new EntityPietanza(dao.getNome(), dao.getPrezzo(), dao.getRicetta());
                lista.add(p);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}
*/

public class DAOPietanza {
    private String nome;
    private float prezzo;
    private EntityRicetta ricetta;

    public DAOPietanza(String nomePietanza) {
        this.nome = nomePietanza;
        List<EntityDoseIngrediente> dosi = new ArrayList<>();

        String query = "SELECT P.prezzo, D.quantita, D.Ingrediente_id " +
                "FROM Pietanza P " +
                "JOIN Ricetta R ON P.Ricetta_id = R.id " +
                "JOIN DoseIngrediente D ON R.DoseIngrediente_id = D.id " +
                "WHERE P.nome = '" + nomePietanza + "';";

        try {
            DBConnectionManager.selectQueryClose(query, rs -> {
                try {
                    while (rs.next()) {
                        this.prezzo = rs.getFloat("prezzo");

                        int quantita = rs.getInt("quantita");
                        int ingredienteId = rs.getInt("Ingrediente_id");

                        DAOIngrediente daoIng = new DAOIngrediente(ingredienteId);
                        EntityIngrediente ingrediente = daoIng.getEntityIngrediente();

                        // Ricetta placeholder (verrà sovrascritta dopo)
                        EntityRicetta ricettaFake = new EntityRicetta(null);
                        EntityDoseIngrediente dose = new EntityDoseIngrediente(quantita, ricettaFake, ingrediente);
                        dosi.add(dose);
                    }
                    this.ricetta = new EntityRicetta(dosi);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch ( SQLException e) {
            e.printStackTrace();
        }
    }

    public String getNome() { return nome; }
    public float getPrezzo() { return prezzo; }
    public EntityRicetta getRicetta() { return ricetta; }
    // ✅ Metodo statico per caricare tutte le pietanze
    public static List<EntityPietanza> getPietanze() {
        List<EntityPietanza> lista = new ArrayList<>();
        String query = "SELECT nome FROM Pietanza;";

        try {
            DBConnectionManager.selectQueryClose(query, rs -> {
                try {
                    while (rs.next()) {
                        String nome = rs.getString("nome");
                        DAOPietanza dao = new DAOPietanza(nome);
                        EntityPietanza p = new EntityPietanza(dao.getNome(), dao.getPrezzo(), dao.getRicetta());
                        lista.add(p);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch ( SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}
package Boundary;


import Controller.ControllerDTO;
import Controller.ControllerOrdine;
import DTO.DTOOrdinabile;
import DTO.DTORiepilogo;

import javax.swing.*;
import java.awt.event.*;
import java.util.List;

public class FormMenuWindow extends JFrame {
    private ControllerOrdine controller;
    private ControllerDTO controllerDTO;
    private int numeroTavolo;
    private FormTavoloWindow formTavoloWindow;

    public FormMenuWindow(List<DTOOrdinabile> lista, int numeroTavolo, FormTavoloWindow formTavoloWindow) {
        this.setTitle("Menu Ordinazione");
        this.setSize(500, 500);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);

        this.controller = new ControllerOrdine();
        this.controllerDTO = new ControllerDTO();
        this.numeroTavolo = numeroTavolo;
        this.formTavoloWindow = formTavoloWindow;

        JLabel titolo = new JLabel("Menu Ordinabili:");
        titolo.setBounds(20, 20, 200, 25);
        add(titolo);

        int y = 60;
        for (DTOOrdinabile dto : lista) {
            JLabel lblNome = new JLabel(dto.getNome());
            lblNome.setBounds(30, y, 200, 25);
            add(lblNome);

            JButton btnAggiungi = new JButton("Aggiungi");
            btnAggiungi.setBounds(250, y, 100, 25);
            btnAggiungi.addActionListener(e -> ClickOnAddToOrderHandler(dto.getID()));
            add(btnAggiungi);

            y += 40;
        }

        JButton btnRiepilogo = new JButton("Riepilogo");
        btnRiepilogo.setBounds(180, y + 20, 120, 30);
        add(btnRiepilogo);

        btnRiepilogo.addActionListener(e -> ClickOnRiepilogoHandler());
    }

    private void ClickOnAddToOrderHandler(int id) {
        String esito = controller.AggiungiOrdinabile(id, numeroTavolo);
        JOptionPane.showMessageDialog(this, esito);
    }

    private void ClickOnRiepilogoHandler() {
        List<DTORiepilogo> lista = controllerDTO.OttieniElementiRiepilogo(numeroTavolo);
        FormRiepilogoWindow riepilogo = new FormRiepilogoWindow(numeroTavolo);
        this.setVisible(false);
        riepilogo.setVisible(true);
        this.dispose();
    }
}

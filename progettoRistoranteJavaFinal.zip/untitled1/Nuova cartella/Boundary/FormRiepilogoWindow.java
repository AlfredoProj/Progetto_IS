package Boundary;

import Controller.ControllerDTO;
import Controller.ControllerOrdine;
import DTO.DTORiepilogo;
import Entity.EntityMenu;

import javax.swing.*;
import java.awt.event.*;
import java.util.List;
import java.util.Map;

public class FormRiepilogoWindow extends JFrame {
    private int numeroTavolo;
    private ControllerOrdine controllerOrdine;
    private ControllerDTO controllerDTO;

    private JPanel panelContenuto;
    private JButton confermaButton, indietroButton;

    public FormRiepilogoWindow(int numeroTavolo) {
        this.numeroTavolo = numeroTavolo;
        this.controllerOrdine = new ControllerOrdine();
        this.controllerDTO = new ControllerDTO();

        setTitle("Riepilogo Ordine");
        setSize(500, 500);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panelContenuto = new JPanel();
        panelContenuto.setLayout(new BoxLayout(panelContenuto, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(panelContenuto);
        scrollPane.setBounds(20, 20, 440, 350);
        add(scrollPane);

        confermaButton = new JButton("Conferma Ordine");
        confermaButton.setBounds(260, 400, 180, 35);
        add(confermaButton);

        indietroButton = new JButton("Indietro");
        indietroButton.setBounds(50, 400, 150, 35);
        add(indietroButton);

        confermaButton.addActionListener(e -> ClickOnConferma());
        indietroButton.addActionListener(e -> ClickOnIndietro());

        aggiornaRiepilogo();
        setLocationRelativeTo(null);
    }

    private void aggiornaRiepilogo() {
        List<DTORiepilogo> listaRiepilogo = controllerDTO.OttieniElementiRiepilogo(numeroTavolo);
        panelContenuto.removeAll();

        for (DTORiepilogo dto : listaRiepilogo) {
            JPanel riga = new JPanel();
            JLabel label = new JLabel(dto.getNome() + " x" + dto.getQuantita());
            JButton btnDecrementa = new JButton("Decrementa");

            btnDecrementa.addActionListener(e -> ClickOnDecrementa(dto.getNome()));

            riga.add(label);
            riga.add(btnDecrementa);
            panelContenuto.add(riga);
        }

        panelContenuto.revalidate();
        panelContenuto.repaint();
    }

    private void ClickOnDecrementa(String nome) {
        int id = getIdFromNome(nome);
        if (id == -1) {
            JOptionPane.showMessageDialog(this, "Errore: ID non trovato per " + nome);
            return;
        }

        controllerOrdine.DecrementaElem(id,numeroTavolo);
        aggiornaRiepilogo();
    }

    private int getIdFromNome(String nome) {
        for (Map.Entry<Integer, Entity.EntityOrdinabile> entry : EntityMenu.getInstance().getMappaOrdinabili().entrySet()) {
            if (entry.getValue().getNome().equals(nome)) {
                return entry.getKey();
            }
        }
        return -1;
    }

    private void ClickOnConferma() {
        controllerOrdine.ConfermaOrdine(numeroTavolo);
        JOptionPane.showMessageDialog(this, "Ordine confermato!");
        this.setVisible(false);
        new FormMainWindow().setVisible(true);
        this.dispose();
    }

    private void ClickOnIndietro() {
        this.setVisible(false);
        new FormMenuWindow(controllerDTO.RichiediMenu(), numeroTavolo, null).setVisible(true);
        this.dispose();
    }
}

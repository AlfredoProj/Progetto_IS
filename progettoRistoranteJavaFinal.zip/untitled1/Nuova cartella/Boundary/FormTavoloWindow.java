package Boundary;

import javax.swing.*;
import java.awt.event.*;
import java.util.List;
import Controller.ControllerOrdine;
import Controller.ControllerDTO;
import DTO.DTOOrdinabile;

public class FormTavoloWindow extends JFrame {
    private JTextField txtNumeroTavolo;
    private JTextField txtNumeroCoperti;
    private JButton btnContinua;
    private JLabel lblMessaggio;
    private ControllerOrdine controller;
    private FormMainWindow mainWindow;

    public void setController(ControllerOrdine controller) {
        this.controller = controller;
    }

    public FormTavoloWindow(FormMainWindow mainWindow) {
        this.mainWindow = mainWindow;
        this.controller = new ControllerOrdine();

        this.setTitle("Creazione Ordine - Tavolo");
        this.setSize(400, 250);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);

        JLabel lblTavolo = new JLabel("Numero Tavolo:");
        lblTavolo.setBounds(50, 30, 120, 25);
        add(lblTavolo);

        txtNumeroTavolo = new JTextField();
        txtNumeroTavolo.setBounds(180, 30, 150, 25);
        add(txtNumeroTavolo);

        JLabel lblCoperti = new JLabel("Numero Coperti:");
        lblCoperti.setBounds(50, 70, 120, 25);
        add(lblCoperti);

        txtNumeroCoperti = new JTextField();
        txtNumeroCoperti.setBounds(180, 70, 150, 25);
        add(txtNumeroCoperti);

        btnContinua = new JButton("Continua");
        btnContinua.setBounds(130, 110, 120, 30);
        add(btnContinua);

        lblMessaggio = new JLabel("");
        lblMessaggio.setBounds(50, 160, 300, 25);
        add(lblMessaggio);

        btnContinua.addActionListener(e -> ClickOnContinuaHandler());
    }

    public void ClickOnContinuaHandler() {
        try {
            int numero = Integer.parseInt(txtNumeroTavolo.getText());
            int coperti = Integer.parseInt(txtNumeroCoperti.getText());

            String errore = controller.ValidaInput(numero, coperti);
            if (!errore.equals("OK")) {
                lblMessaggio.setText(errore);
                return;
            }

            List<DTOOrdinabile> lista = new ControllerDTO().RichiediMenu();
            FormMenuWindow formMenu = new FormMenuWindow(lista, numero, this);
            this.setVisible(false);
            formMenu.setVisible(true);
            this.dispose();

        } catch (NumberFormatException ex) {
            lblMessaggio.setText("Inserisci numeri validi.");
        }
    }

    public void tornaAlMain() {
        mainWindow.setVisible(true);
    }
}

package Boundary;

import javax.swing.*;
import java.awt.event.*;

public class FormMainWindow extends JFrame {
    private JButton btnCalcolaConto;
    private JButton btnCreaOrdine;
    private Controller.ControllerCassiere controllerCassiere;

    public FormMainWindow() {
        this.setTitle("Main Window");
        this.setSize(400, 300);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLayout(null);

        controllerCassiere = new Controller.ControllerCassiere();

        btnCalcolaConto = new JButton("Calcola Conto");
        btnCalcolaConto.setBounds(120, 70, 160, 40);
        this.add(btnCalcolaConto);

        btnCalcolaConto.addActionListener(e -> ClickOnCalcolaContoHandler());

        btnCreaOrdine = new JButton("Crea Ordine");
        btnCreaOrdine.setBounds(120, 130, 160, 40);
        this.add(btnCreaOrdine);

        btnCreaOrdine.addActionListener(e -> CreaOrdineOnClickHandler());
    }

    public void ClickOnCalcolaContoHandler() {
        FormCalcoloWindow formCalcolo = new FormCalcoloWindow();
        formCalcolo.setController(controllerCassiere);
        this.setVisible(false);
        formCalcolo.setVisible(true);
    }

    public void CreaOrdineOnClickHandler() {
        FormTavoloWindow formTavolo = new FormTavoloWindow(this);
        this.setVisible(false);
        formTavolo.setVisible(true);
    }

    public static void main(String[] args) {
        FormMainWindow form = new FormMainWindow();
        form.setVisible(true);
    }
}

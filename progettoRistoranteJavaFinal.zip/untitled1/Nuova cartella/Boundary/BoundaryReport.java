package Boundary;

import javax.swing.*;
import java.awt.event.*;
import java.util.List;
import Controller.ControllerReport;
import DTO.DTOIngrediente;

public class BoundaryReport extends JFrame {
    private JButton btnGeneraReport;
    private JTextArea textAreaRisultato;
    private ControllerReport controller;

    public BoundaryReport() {
        this.setTitle("Report Magazzino");
        this.setSize(400, 300);
        this.setLayout(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        btnGeneraReport = new JButton("Genera Report");
        btnGeneraReport.setBounds(120, 30, 160, 30);
        add(btnGeneraReport);

        textAreaRisultato = new JTextArea();
        textAreaRisultato.setBounds(50, 80, 300, 150);
        textAreaRisultato.setEditable(false);
        add(textAreaRisultato);

        btnGeneraReport.addActionListener(e -> ClickOnGeneraReportHandler());
    }

    public void ClickOnGeneraReportHandler() {
        controller = new ControllerReport();
        DTOIngrediente dto = controller.GeneraReport();
        updateGUI(dto);
    }

    public void updateGUI(DTOIngrediente dto) {
        List<String> lista = dto.getLista();
        if (lista.isEmpty()) {
            textAreaRisultato.setText("Tutti gli ingredienti sono disponibili.");
        } else {
            StringBuilder sb = new StringBuilder("Ingredienti sotto soglia:\n");
            for (String nome : lista) {
                sb.append("- ").append(nome).append("\n");
            }
            textAreaRisultato.setText(sb.toString());
        }
    }

    public static void main(String[] args) {
        BoundaryReport form = new BoundaryReport();
        form.setVisible(true);
    }
}

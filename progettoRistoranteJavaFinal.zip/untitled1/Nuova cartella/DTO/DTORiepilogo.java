package DTO;

public class DTORiepilogo {
        private int id;
        private String nome;
        private int quantita;

        public void setNome(String nome) {
            this.nome = nome;
        }

        public void setQuantita(int quantita) {
            this.quantita = quantita;
        }

        public String getNome() {
            return nome;
        }

        public int getQuantita() {
            return quantita;
        }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}


package DTO;


public class DTOOrdinabile {
    private int id;
    private String nome;

    public void setID(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getID() {
        return id;
    }

    public String getNome() {
        return nome;
    }
}

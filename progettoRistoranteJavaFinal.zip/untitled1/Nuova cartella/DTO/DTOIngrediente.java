package DTO;
import java.util.List;

    public class DTOIngrediente {
        private List<String> lista;

        public void setLista(List<String> lista) {
            this.lista = lista;
        }

        public List<String> getLista() {
            return lista;
        }
    }


package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.*;

public class DAOPietanza {
    private String nome;
    private float prezzo;
    private EntityRicetta ricetta;

    public DAOPietanza(String nomePietanza) {
        this.nome = nomePietanza;

        String query = "SELECT P.prezzo, P.Ricetta_id FROM Pietanza P WHERE P.nome = '" + nomePietanza + "';";

        try {
            DBConnectionManager.selectQueryClose(query, rs -> {
                try {
                    if (rs.next()) {
                        this.prezzo = rs.getFloat("prezzo");
                        int ricettaId = rs.getInt("Ricetta_id");

                        // Ora la ricetta viene caricata dalla nuova DAORicetta
                        DAORicetta daoRicetta = new DAORicetta(ricettaId);
                        this.ricetta = daoRicetta.getEntityRicetta();
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public String getNome() { return nome; }
    public float getPrezzo() { return prezzo; }
    public EntityRicetta getRicetta() { return ricetta; }

    // Metodo statico per caricare tutte le pietanze
    public static List<EntityPietanza> getPietanze() {
        List<EntityPietanza> lista = new ArrayList<>();
        String query = "SELECT nome FROM Pietanza;";

        try {
            DBConnectionManager.selectQueryClose(query, rs -> {
                try {
                    while (rs.next()) {
                        String nome = rs.getString("nome");
                        DAOPietanza dao = new DAOPietanza(nome);
                        EntityPietanza p = new EntityPietanza(dao.getNome(), dao.getPrezzo(), dao.getRicetta());
                        lista.add(p);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}

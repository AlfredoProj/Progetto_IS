package database;

import Entity.EntityDoseIngrediente;
import Entity.EntityIngrediente;
import Entity.EntityRicetta;
import java.util.List;
import java.util.ArrayList;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAODoseIngrediente {
    private int quantita;
    private EntityIngrediente ingrediente;
    private EntityRicetta ricetta; // sarà impostata esternamente

    public DAODoseIngrediente(int id) {
        caricaDaDB(id);
    }

    private void caricaDaDB(int id) {
        String query = "SELECT quantita, Ingrediente_nome FROM DoseIngrediente WHERE id = " + id + ";";

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            if (rs.next()) {
                this.quantita = rs.getInt("quantita");
                String nomeIngrediente = rs.getString("Ingrediente_nome");
                this.ingrediente = new EntityIngrediente(nomeIngrediente);
                this.ricetta = null; // da impostare esternamente
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public int getQuantita() {
        return quantita;
    }

    public EntityIngrediente getIngrediente() {
        return ingrediente;
    }

    public EntityRicetta getRicetta() {
        return ricetta;
    }

    public void setRicetta(EntityRicetta ricetta) {
        this.ricetta = ricetta;
    }

    public EntityDoseIngrediente getEntityDoseIngrediente() {
        return new EntityDoseIngrediente(quantita, ricetta, ingrediente);
    }
    public static List<EntityDoseIngrediente> getDosi() {
        List<EntityDoseIngrediente> lista = new ArrayList<>();

        String query = "SELECT id FROM DoseIngrediente";

        try {
            DBConnectionManager.selectQueryClose(query, rs -> {
                try {
                    while (rs.next()) {
                        int id = rs.getInt("id");
                        DAODoseIngrediente dao = new DAODoseIngrediente(id);
                        EntityDoseIngrediente dose = dao.getEntityDoseIngrediente();
                        lista.add(dose);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }

}
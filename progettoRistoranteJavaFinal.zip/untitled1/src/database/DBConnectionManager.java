package database;

import java.sql.*;

public class DBConnectionManager {

    public static String url = "jdbc:mysql://localhost:3306/";
    public static String dbName = "erschema";
    public static String driver = "com.mysql.cj.jdbc.Driver";
    public static String userName = "root";
    public static String password = "Wjp59ujy6kdpvke!!!";

    // Carica il driver UNA VOLTA SOLA all'avvio della classe
    static {
        try {
            Class.forName(driver);
            System.out.println("Driver JDBC caricato correttamente.");
        } catch (ClassNotFoundException e) {
            System.err.println("Errore: driver JDBC non trovato.");
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url + dbName, userName, password);
    }

    public static void closeConnection(Connection c) throws SQLException {
        if (c != null) c.close();
    }

    public static ResultSet selectQuery(String query) throws SQLException {
        Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(query); //  non prevede la chiusura della connessione
    }

    // Versione che è decisamente più sicura con chiusura
    public static void selectQueryClose(String query, ResultHandler handler) throws SQLException {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(query);
            handler.handle(rs);
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }

    public static int updateQuery(String query) throws SQLException {
        try (Connection conn = getConnection(); Statement stmt = conn.createStatement()) {
            return stmt.executeUpdate(query);
        }
    }

    public static Integer updateQueryReturnGeneratedKey(String query) throws SQLException {
        Integer ret = null;
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate(query, Statement.RETURN_GENERATED_KEYS);
            ResultSet rs = stmt.getGeneratedKeys();
            if (rs.next()) {
                ret = rs.getInt(1);
            }
        }
        return ret;
    }
}

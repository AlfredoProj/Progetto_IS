package database;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Entity.*;
public class DAOMenu {
    public static void caricaMenu(EntityMenu menu) {
        Map<Integer, EntityOrdinabile> mappa = menu.getMappaOrdinabili();
        List<EntityOrdinabile> lista = new ArrayList<>();

        List<EntityPietanza> tutteLePietanze = DAOPietanza.getPietanze();
        List<EntityMenuFisso> tuttiIMenuFissi = DAOMenuFisso.getMenuFissi();

        String queryMenu = "SELECT id, Pietanza_nome, MenuFisso_nome FROM Menu";

        try {
            DBConnectionManager.selectQueryClose(queryMenu, rs -> {
                try {
                    while (rs.next()) {
                        int id = rs.getInt("id");
                        String nomePietanza = rs.getString("Pietanza_nome");
                        String nomeMenuFisso = rs.getString("MenuFisso_nome");

                        EntityOrdinabile ordinabile = null;

                        if (nomePietanza != null) {
                            for (EntityPietanza p : tutteLePietanze) {
                                if (p.getNome().equals(nomePietanza)) {
                                    ordinabile = p;
                                    break;
                                }
                            }
                        } else if (nomeMenuFisso != null) {
                            for (EntityMenuFisso mf : tuttiIMenuFissi) {
                                if (mf.getNome().equals(nomeMenuFisso)) {
                                    ordinabile = mf;
                                    break;
                                }
                            }
                        }

                        if (ordinabile != null) {
                            mappa.put(id, ordinabile);
                            lista.add(ordinabile);
                        }
                    }

                    menu.setListaOrdinabili(lista);

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}



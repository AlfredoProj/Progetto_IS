package database;
import Entity.EntityIngrediente;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class DAOMagazzino {
    private Map<EntityIngrediente, Integer> scorte = new HashMap<>();

    public DAOMagazzino() {
        caricaDaDB();
    }

    private void caricaDaDB() {
        String query = "SELECT quantita_disponibile, Ingrediente_nome FROM Magazzino";

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                int quantita = rs.getInt("quantita_disponibile");
                String ingredienteNome = rs.getString("Ingrediente_nome");

                EntityIngrediente ingr = new EntityIngrediente(ingredienteNome);  // usa costruttore con DAO interno

                scorte.put(ingr, quantita);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Map<EntityIngrediente, Integer> getScorte() {
        return scorte;
    }

    public void aggiornaSingolaScorta(EntityIngrediente ingrediente, int nuovaQuantita) {
        String query = "UPDATE magazzino SET quantita_disponibile = " + nuovaQuantita +
                " WHERE Ingrediente_nome = '" + ingrediente.getNome() + "';";
        try {
            DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int leggiQuantita(EntityIngrediente ingrediente) {
        String query = "SELECT quantita FROM Ingrediente WHERE nome = '" + ingrediente.getNome() + "';";
        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            if (rs.next()) {
                return rs.getInt("quantita");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    private void aggiornaQuantita(EntityIngrediente ingrediente, int nuovaQuantita) {
        String query = "UPDATE Ingrediente SET quantita = " + nuovaQuantita +
                " WHERE nome = '" + ingrediente.getNome() + "';";
        try {
            DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

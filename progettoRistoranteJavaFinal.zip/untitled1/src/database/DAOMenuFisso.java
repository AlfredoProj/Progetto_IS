package database;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Entity.EntityMenuFisso;
import Entity.EntityPietanza;

public class DAOMenuFisso {

    private String nome;
    private float prezzo;
    private List<EntityPietanza> portate = new ArrayList<>();

    public DAOMenuFisso(String nomeMenu) {
        this.nome = nomeMenu;

        String queryMenu = "SELECT * FROM MenuFisso WHERE nome = '" + nomeMenu + "'";

        try {
            DBConnectionManager.selectQueryClose(queryMenu, rs -> {
                try {
                    if (rs.next()) {
                        this.prezzo = rs.getFloat("prezzo");


                        // Query per recuperare le pietanze associate
                        String queryPietanze = "SELECT Pietanza.nome " +
                                "FROM MenuFisso_has_Pietanza " +
                                "JOIN Pietanza ON Pietanza.nome = MenuFisso_has_Pietanza.Pietanza_nome " +
                                "WHERE MenuFisso_has_Pietanza.MenuFisso_nome = '" + nomeMenu + "'";

                        DBConnectionManager.selectQueryClose(queryPietanze, rsPietanze -> {
                            try {
                                while (rsPietanze.next()) {
                                    String nomePietanza = rsPietanze.getString("nome");
                                    EntityPietanza p = new EntityPietanza(nomePietanza);
                                    portate.add(p);
                                }
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                        });
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch ( SQLException e) {
            e.printStackTrace();
        }
    }

    public String getNome() {
        return nome;
    }

    public float getPrezzo() {
        return prezzo;
    }

    public List<EntityPietanza> getPietanze() {
        return portate;
    }

    public List<EntityPietanza> getPortate() {
        return portate;
    }

    //  Metodo statico per precaricare tutti i MenuFisso
    public static List<EntityMenuFisso> getMenuFissi() {
        List<EntityMenuFisso> lista = new ArrayList<>();
        String query = "SELECT nome FROM MenuFisso;";

        try {
            DBConnectionManager.selectQueryClose(query, rs -> {
                try {
                    while (rs.next()) {
                        String nomeMenu = rs.getString("nome");
                        DAOMenuFisso dao = new DAOMenuFisso(nomeMenu);
                        EntityMenuFisso mf = new EntityMenuFisso(dao.getNome(), dao.getPrezzo(), dao.getPietanze());
                        lista.add(mf);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch (  SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}

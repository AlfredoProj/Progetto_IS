package database;

import Entity.EntityIngrediente;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAOIngrediente {
    private EntityIngrediente ingrediente;
    private String nome;
    private int quantitaSoglia;

    // Costruttore che carica da DB in base al nome
    public DAOIngrediente(String nome) {
        this.nome = nome;
        caricaDaDB(nome);
    }

    private void caricaDaDB(String nome) {
        String query = "SELECT quantita_soglia FROM Ingrediente WHERE nome = '" + nome + "';";
        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            if (rs.next()) {
                this.quantitaSoglia = rs.getInt("quantita_soglia");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Costruttore alternativo per aggiornamenti
    public DAOIngrediente(EntityIngrediente ingrediente) {
        this.ingrediente = ingrediente;
    }

    // Restituisce l'oggetto Entity corrispondente
    public EntityIngrediente getEntityIngrediente() {
        return new EntityIngrediente(nome, quantitaSoglia);
    }

    public String getNome() {
        return nome;
    }

    public int getQuantitaSoglia() {
        return quantitaSoglia;
    }

    //  Aggiorna la quantità nel DB (anche se la tabella non ha il campo quantità, questo rimane per compatibilità con Magazzino)
    public void aggiornaQuantita(int nuovaQuantita) {
        String query = "UPDATE Ingrediente SET quantita = " + nuovaQuantita +
                " WHERE nome = '" + ingrediente.getNome() + "';";
        try {
            DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //  Metodo statico per precaricare tutti gli ingredienti (nome + soglia)
    public static List<EntityIngrediente> getIngredienti() {
        List<EntityIngrediente> lista = new ArrayList<>();
        String query = "SELECT nome, quantita_soglia FROM Ingrediente;";
        try {
            DBConnectionManager.selectQueryClose(query, rs -> {
                try {
                    while (rs.next()) {
                        String nome = rs.getString("nome");
                        int soglia = rs.getInt("quantita_soglia");
                        EntityIngrediente ingr = new EntityIngrediente(nome, soglia);
                        lista.add(ingr);
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            });
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return lista;
    }
}

package database;
import java.sql.ResultSet;
import java.sql.SQLException;

import Entity.EntityOrdine;

public class DAOOrdine {
    private EntityOrdine ordine;

    public DAOOrdine(EntityOrdine ordine) {
        this.ordine = ordine;
    }

    public void createOrdine() {
        String query = "INSERT INTO Ordine (stato) VALUES ( " + ordine.getStato() + ");";
        try {
            DBConnectionManager.updateQuery(query);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void deleteOrdine() {
        int ordineId = -1;
        String getIdQuery = "SELECT Ordine_id FROM Tavolo WHERE numero = " + ordine.getTavolo().getNumero();
        try (ResultSet rs = DBConnectionManager.selectQuery(getIdQuery)) {
            if (rs.next()) {
                ordineId = rs.getInt("Ordine_id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (ordineId != -1) {
            String deleteQuery = "DELETE FROM Ordine WHERE id = " + ordineId;
            try {
                DBConnectionManager.updateQuery(deleteQuery);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
package database;

import Entity.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DAORicetta {
    private int ricettaId;
    private List<EntityDoseIngrediente> dosi = new ArrayList<>();

    public DAORicetta(int ricettaId) {
        this.ricettaId = ricettaId;
        caricaDosi();
    }

    private void caricaDosi() {
        String query = "SELECT quantita, Ingrediente_nome FROM DoseIngrediente WHERE Ricetta_id = " + ricettaId + ";";
        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                int quantita = rs.getInt("quantita");
                String nomeIngrediente = rs.getString("Ingrediente_nome");

                DAOIngrediente daoIng = new DAOIngrediente(nomeIngrediente);
                EntityIngrediente ingrediente = daoIng.getEntityIngrediente();

                EntityDoseIngrediente dose = new EntityDoseIngrediente(quantita, null, ingrediente);
                dosi.add(dose);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public EntityRicetta getEntityRicetta() {
        return new EntityRicetta(dosi);
    }

    public List<EntityDoseIngrediente> getDosi() {
        return dosi;
    }

    public static List<EntityRicetta> getRicette() {
        List<EntityRicetta> lista = new ArrayList<>();
        String query = "SELECT id FROM Ricetta;";

        try {
            ResultSet rs = DBConnectionManager.selectQuery(query);
            while (rs.next()) {
                int id = rs.getInt("id");
                DAORicetta dao = new DAORicetta(id);
                lista.add(dao.getEntityRicetta());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return lista;
    }
}

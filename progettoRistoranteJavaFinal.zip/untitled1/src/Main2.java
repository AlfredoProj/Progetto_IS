import Boundary.BoundaryReport;
import Boundary.FormMainWindow;
import Entity.EntityMagazzino;
import Entity.EntityRistorante;

public class Main2 {
    public static void main(String[] args) {
        // Precaricamento ENTITÀ (che internamente usano i DAO)
        EntityRistorante.getInstance();     // Tavoli + Menu + Pietanze + Ricette
        EntityMagazzino.getInstance();      // Ingredienti + Scorte

        // Avvio GUI
        BoundaryReport form = new BoundaryReport();
        form.setVisible(true);
    }
}

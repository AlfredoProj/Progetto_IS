
import Entity.*;
import Boundary.*;

public class Main {
    public static void main(String[] args) {
        // Precaricamento ENTITÀ (che internamente usano i DAO)
        EntityRistorante.getInstance();     // Tavoli + Menu + Pietanze + Ricette
        EntityMagazzino.getInstance();      // Ingredienti + Scorte

        // Avvio GUI
        FormMainWindow form = new FormMainWindow();
        form.setVisible(true);
    }
}

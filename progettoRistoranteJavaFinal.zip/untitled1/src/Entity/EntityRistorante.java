package Entity;
import java.util.ArrayList;
import java.util.List;

public class EntityRistorante {
    private List<EntityTavolo> lista_tavoli = new ArrayList<>();
    private EntityMenu menu;
    private static EntityRistorante instance = null;

    private EntityRistorante() {
        // Carica i tavoli dal database
        for (int i = 1; i <= 5; i++) {
            EntityTavolo t = new EntityTavolo(i);
            lista_tavoli.add(t);
        }

        // Carica il menu (che precarica tutto)
        this.menu = EntityMenu.getInstance();
    }

    public static EntityRistorante getInstance() {
        if (instance == null) instance = new EntityRistorante();
        return instance;
    }

    public void AggiungiTavolo(EntityTavolo t) {
        lista_tavoli.add(t);
    }

    public void AggiungiMenu() {
        this.menu = EntityMenu.getInstance();
    }

    public EntityTavolo TrovaTavolo(int numero) {
        return lista_tavoli.stream().filter(t -> t.getNumero() == numero).findFirst().orElse(null);
    }
    public List<EntityTavolo> getListaTavoli() {
        return this.lista_tavoli;
    }
}
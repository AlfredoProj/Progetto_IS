package Entity;

public class EntityDoseIngrediente {
    private int quantita;
    private EntityRicetta ricetta;
    private EntityIngrediente ingrediente;

    public EntityDoseIngrediente(int quantita, EntityRicetta ricetta, EntityIngrediente ingrediente) {
        this.quantita = quantita;
        this.ricetta = ricetta;
        this.ingrediente = ingrediente;
    }
    // Costruttore basato sulla DAO
    public EntityDoseIngrediente(database.DAODoseIngrediente dao) {
        this.quantita = dao.getQuantita();
        this.ingrediente = dao.getIngrediente();
        this.ricetta = dao.getRicetta(); // può essere null, da settare dopo
    }
    public int getQuantita() { return quantita; }
    public EntityIngrediente getIngrediente() { return ingrediente; }
    public EntityRicetta getRicetta() { return ricetta; }

    public void setQuantita(int quantita) {
        this.quantita = quantita;
    }

    public void setRicetta(EntityRicetta ricetta) {
        this.ricetta = ricetta;
    }

    public void setIngrediente(EntityIngrediente ingrediente) {
        this.ingrediente = ingrediente;
    }
}

package Boundary;

import Controller.ControllerCassiere;

import javax.swing.*;
import java.awt.event.*;

public class FormCalcoloWindow extends JFrame {
    private JTextField txtNumeroTavolo;
    private JTextField txtNumeroCoperti;
    private JButton btnContinua;
    private JLabel lblRisultato;
    private ControllerCassiere controller;

    public FormCalcoloWindow() {
        this.setTitle("Calcolo Conto");
        this.setSize(400, 300);
        this.setLayout(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);

        JLabel lblTavolo = new JLabel("Numero Tavolo:");
        lblTavolo.setBounds(50, 30, 120, 25);
        add(lblTavolo);

        txtNumeroTavolo = new JTextField();
        txtNumeroTavolo.setBounds(180, 30, 150, 25);
        add(txtNumeroTavolo);





        btnContinua = new JButton("Continua");
        btnContinua.setBounds(130, 110, 120, 30);
        add(btnContinua);

        lblRisultato = new JLabel("");
        lblRisultato.setBounds(50, 160, 300, 25);
        add(lblRisultato);

        btnContinua.addActionListener(e -> ClickOnContinuaHandler());
    }

    public void setController(ControllerCassiere controller) {
        this.controller = controller;
    }

    public void ClickOnContinuaHandler() {
        try {
            int numero = Integer.parseInt(txtNumeroTavolo.getText());


                if (!controller.ValidaInput(numero)) {
                    lblRisultato.setText("Errore: input non valido.");
                    return;
                }

            double conto = controller.CalcolaConto(numero);

            if (conto < 0) {
                lblRisultato.setText("Errore: tavolo non trovato o ordine assente.");
            } else {
                lblRisultato.setText("Conto totale: " + conto + " €");
            }

        } catch (NumberFormatException ex) {
            lblRisultato.setText("Inserisci numeri validi.");
        }
    }
}
-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: erschema
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doseingrediente`
--

DROP TABLE IF EXISTS `doseingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doseingrediente` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quantita` int unsigned NOT NULL,
  `Ingrediente_nome` varchar(45) NOT NULL,
  `Ricetta_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_DoseIngrediente_Ingrediente1_idx` (`Ingrediente_nome`),
  KEY `fk_DoseIngrediente_Ricetta` (`Ricetta_id`),
  CONSTRAINT `fk_DoseIngrediente_Ingrediente1` FOREIGN KEY (`Ingrediente_nome`) REFERENCES `ingrediente` (`nome`),
  CONSTRAINT `fk_DoseIngrediente_Ricetta` FOREIGN KEY (`Ricetta_id`) REFERENCES `ricetta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doseingrediente`
--

LOCK TABLES `doseingrediente` WRITE;
/*!40000 ALTER TABLE `doseingrediente` DISABLE KEYS */;
INSERT INTO `doseingrediente` VALUES (1,5,'Pomodoro',1),(2,3,'Mozzarella',1),(3,10,'Pasta',2),(4,1,'Basilico',2),(5,4,'Prosciutto',3),(6,3,'Funghi',NULL),(7,3,'Pasta',NULL),(8,3,'Pasta',1),(9,2,'Funghi',1),(10,2,'Pomodoro',2),(11,3,'Mozzarella',2),(12,1,'Basilico',2),(13,3,'Pasta',3),(14,2,'Prosciutto',3),(15,2,'Pomodoro',3),(16,6,'Pasta',6),(17,3,'Pomodoro',6),(18,5,'Mozzarella',6),(19,3,'Funghi',6),(20,6,'Pasta',5),(21,3,'Pomodoro',5),(22,5,'Mozzarella',5),(23,4,'Prosciutto',5),(24,8,'Pasta',4),(25,2,'Basilico',4);
/*!40000 ALTER TABLE `doseingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingrediente`
--

DROP TABLE IF EXISTS `ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingrediente` (
  `nome` varchar(45) NOT NULL,
  `quantita_soglia` int unsigned NOT NULL,
  PRIMARY KEY (`nome`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingrediente`
--

LOCK TABLES `ingrediente` WRITE;
/*!40000 ALTER TABLE `ingrediente` DISABLE KEYS */;
INSERT INTO `ingrediente` VALUES ('Basilico',10),('Funghi',10),('Mozzarella',15),('Pasta',30),('Pomodoro',20),('Prosciutto',12);
/*!40000 ALTER TABLE `ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `magazzino`
--

DROP TABLE IF EXISTS `magazzino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `magazzino` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quantita_disponibile` int unsigned NOT NULL,
  `Ingrediente_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Magazzino_Ingrediente1_idx` (`Ingrediente_nome`),
  CONSTRAINT `fk_Magazzino_Ingrediente1` FOREIGN KEY (`Ingrediente_nome`) REFERENCES `ingrediente` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `magazzino`
--

LOCK TABLES `magazzino` WRITE;
/*!40000 ALTER TABLE `magazzino` DISABLE KEYS */;
INSERT INTO `magazzino` VALUES (1,21,'Pomodoro'),(2,0,'Mozzarella'),(3,0,'Pasta'),(4,19,'Basilico'),(5,16,'Prosciutto'),(6,31,'Funghi');
/*!40000 ALTER TABLE `magazzino` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `MenuFisso_nome` varchar(45) DEFAULT NULL,
  `Pietanza_nome` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_Menu_MenuFisso1_idx` (`MenuFisso_nome`),
  KEY `fk_Menu_Pietanza1_idx` (`Pietanza_nome`),
  CONSTRAINT `fk_Menu_MenuFisso1` FOREIGN KEY (`MenuFisso_nome`) REFERENCES `menufisso` (`nome`),
  CONSTRAINT `fk_Menu_Pietanza1` FOREIGN KEY (`Pietanza_nome`) REFERENCES `pietanza` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,'Menu Pizza Classico',NULL),(2,'Menu Pasta Vegetariana',NULL),(3,NULL,'Pizza Margherita'),(4,NULL,'Pizza Bianca'),(5,NULL,'Spaghetti al Pomodoro'),(6,NULL,'Pasta al Basilico'),(7,NULL,'Pizza Prosciutto'),(8,NULL,'Pizza ai Funghi');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menufisso`
--

DROP TABLE IF EXISTS `menufisso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menufisso` (
  `nome` varchar(45) NOT NULL,
  `prezzo` decimal(5,2) unsigned NOT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menufisso`
--

LOCK TABLES `menufisso` WRITE;
/*!40000 ALTER TABLE `menufisso` DISABLE KEYS */;
INSERT INTO `menufisso` VALUES ('Menu Pasta Vegetariana',15.00),('Menu Pizza Classico',16.00);
/*!40000 ALTER TABLE `menufisso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menufisso_has_pietanza`
--

DROP TABLE IF EXISTS `menufisso_has_pietanza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menufisso_has_pietanza` (
  `MenuFisso_nome` varchar(45) NOT NULL,
  `Pietanza_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`MenuFisso_nome`,`Pietanza_nome`),
  KEY `fk_MenuFisso_has_Pietanza_Pietanza1_idx` (`Pietanza_nome`),
  CONSTRAINT `fk_MenuFisso_has_Pietanza_MenuFisso1` FOREIGN KEY (`MenuFisso_nome`) REFERENCES `menufisso` (`nome`),
  CONSTRAINT `fk_MenuFisso_has_Pietanza_Pietanza1` FOREIGN KEY (`Pietanza_nome`) REFERENCES `pietanza` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menufisso_has_pietanza`
--

LOCK TABLES `menufisso_has_pietanza` WRITE;
/*!40000 ALTER TABLE `menufisso_has_pietanza` DISABLE KEYS */;
INSERT INTO `menufisso_has_pietanza` VALUES ('Menu Pasta Vegetariana','Pasta al Basilico'),('Menu Pizza Classico','Pizza Margherita'),('Menu Pizza Classico','Pizza Prosciutto'),('Menu Pasta Vegetariana','Spaghetti al Pomodoro');
/*!40000 ALTER TABLE `menufisso_has_pietanza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordine`
--

DROP TABLE IF EXISTS `ordine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordine` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `stato` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordine`
--

LOCK TABLES `ordine` WRITE;
/*!40000 ALTER TABLE `ordine` DISABLE KEYS */;
INSERT INTO `ordine` VALUES (1,1),(2,1),(3,1),(4,1);
/*!40000 ALTER TABLE `ordine` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordine_has_menufisso`
--

DROP TABLE IF EXISTS `ordine_has_menufisso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordine_has_menufisso` (
  `Ordine_id` int unsigned NOT NULL,
  `MenuFisso_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`Ordine_id`,`MenuFisso_nome`),
  KEY `fk_Ordine_has_MenuFisso_Ordine1_idx` (`Ordine_id`),
  KEY `fk_Ordine_has_MenuFisso_MenuFisso1_idx` (`MenuFisso_nome`),
  CONSTRAINT `fk_Ordine_has_MenuFisso_MenuFisso1` FOREIGN KEY (`MenuFisso_nome`) REFERENCES `menufisso` (`nome`),
  CONSTRAINT `fk_Ordine_has_MenuFisso_Ordine1` FOREIGN KEY (`Ordine_id`) REFERENCES `ordine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordine_has_menufisso`
--

LOCK TABLES `ordine_has_menufisso` WRITE;
/*!40000 ALTER TABLE `ordine_has_menufisso` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordine_has_menufisso` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordine_has_pietanza`
--

DROP TABLE IF EXISTS `ordine_has_pietanza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordine_has_pietanza` (
  `Ordine_id` int unsigned NOT NULL,
  `Pietanza_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`Ordine_id`,`Pietanza_nome`),
  KEY `fk_Ordine_has_Pietanza_Ordine1_idx` (`Ordine_id`),
  KEY `fk_Ordine_has_Pietanza_Pietanza1_idx` (`Pietanza_nome`),
  CONSTRAINT `fk_Ordine_has_Pietanza_Ordine1` FOREIGN KEY (`Ordine_id`) REFERENCES `ordine` (`id`),
  CONSTRAINT `fk_Ordine_has_Pietanza_Pietanza1` FOREIGN KEY (`Pietanza_nome`) REFERENCES `pietanza` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordine_has_pietanza`
--

LOCK TABLES `ordine_has_pietanza` WRITE;
/*!40000 ALTER TABLE `ordine_has_pietanza` DISABLE KEYS */;
/*!40000 ALTER TABLE `ordine_has_pietanza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pietanza`
--

DROP TABLE IF EXISTS `pietanza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pietanza` (
  `nome` varchar(45) NOT NULL,
  `prezzo` decimal(5,2) unsigned NOT NULL,
  `Ricetta_id` int unsigned NOT NULL,
  PRIMARY KEY (`nome`),
  KEY `fk_Pietanza_Ricetta1_idx` (`Ricetta_id`),
  CONSTRAINT `fk_Pietanza_Ricetta1` FOREIGN KEY (`Ricetta_id`) REFERENCES `ricetta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pietanza`
--

LOCK TABLES `pietanza` WRITE;
/*!40000 ALTER TABLE `pietanza` DISABLE KEYS */;
INSERT INTO `pietanza` VALUES ('Pasta al Basilico',9.50,4),('Pizza ai Funghi',10.50,6),('Pizza Bianca',7.50,2),('Pizza Margherita',8.50,1),('Pizza Prosciutto',10.00,5),('Spaghetti al Pomodoro',9.00,3);
/*!40000 ALTER TABLE `pietanza` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ricetta`
--

DROP TABLE IF EXISTS `ricetta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ricetta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ricetta`
--

LOCK TABLES `ricetta` WRITE;
/*!40000 ALTER TABLE `ricetta` DISABLE KEYS */;
INSERT INTO `ricetta` VALUES (1),(2),(3),(4),(5),(6);
/*!40000 ALTER TABLE `ricetta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tavolo`
--

DROP TABLE IF EXISTS `tavolo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tavolo` (
  `numero` int unsigned NOT NULL AUTO_INCREMENT,
  `postiMax` int unsigned NOT NULL,
  `Ordine_id` int unsigned DEFAULT NULL,
  `numero_coperti` int DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `fk_Tavolo_Ordine1_idx` (`Ordine_id`),
  CONSTRAINT `fk_Tavolo_Ordine1` FOREIGN KEY (`Ordine_id`) REFERENCES `ordine` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tavolo`
--

LOCK TABLES `tavolo` WRITE;
/*!40000 ALTER TABLE `tavolo` DISABLE KEYS */;
INSERT INTO `tavolo` VALUES (1,4,NULL,0),(2,2,NULL,0),(3,6,NULL,0),(4,4,NULL,3),(5,8,NULL,0);
/*!40000 ALTER TABLE `tavolo` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-15 13:33:36

-- MySQL dump 10.13  Distrib 8.0.42, for Win64 (x86_64)
--
-- Host: localhost    Database: erschema
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doseingrediente`
--

DROP TABLE IF EXISTS `doseingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `doseingrediente` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quantita` int unsigned NOT NULL,
  `Ingrediente_nome` varchar(45) NOT NULL,
  `Ricetta_id` int unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_DoseIngrediente_Ingrediente1_idx` (`Ingrediente_nome`),
  KEY `fk_DoseIngrediente_Ricetta` (`Ricetta_id`),
  CONSTRAINT `fk_DoseIngrediente_Ingrediente1` FOREIGN KEY (`Ingrediente_nome`) REFERENCES `ingrediente` (`nome`),
  CONSTRAINT `fk_DoseIngrediente_Ricetta` FOREIGN KEY (`Ricetta_id`) REFERENCES `ricetta` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ingrediente`
--

DROP TABLE IF EXISTS `ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingrediente` (
  `nome` varchar(45) NOT NULL,
  `quantita_soglia` int unsigned NOT NULL,
  PRIMARY KEY (`nome`),
  UNIQUE KEY `nome_UNIQUE` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `magazzino`
--

DROP TABLE IF EXISTS `magazzino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `magazzino` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `quantita_disponibile` int unsigned NOT NULL,
  `Ingrediente_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_Magazzino_Ingrediente1_idx` (`Ingrediente_nome`),
  CONSTRAINT `fk_Magazzino_Ingrediente1` FOREIGN KEY (`Ingrediente_nome`) REFERENCES `ingrediente` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `MenuFisso_nome` varchar(45) DEFAULT NULL,
  `Pietanza_nome` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_Menu_MenuFisso1_idx` (`MenuFisso_nome`),
  KEY `fk_Menu_Pietanza1_idx` (`Pietanza_nome`),
  CONSTRAINT `fk_Menu_MenuFisso1` FOREIGN KEY (`MenuFisso_nome`) REFERENCES `menufisso` (`nome`),
  CONSTRAINT `fk_Menu_Pietanza1` FOREIGN KEY (`Pietanza_nome`) REFERENCES `pietanza` (`nome`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menufisso`
--

DROP TABLE IF EXISTS `menufisso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menufisso` (
  `nome` varchar(45) NOT NULL,
  `prezzo` decimal(5,2) unsigned NOT NULL,
  PRIMARY KEY (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menufisso_has_pietanza`
--

DROP TABLE IF EXISTS `menufisso_has_pietanza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menufisso_has_pietanza` (
  `MenuFisso_nome` varchar(45) NOT NULL,
  `Pietanza_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`MenuFisso_nome`,`Pietanza_nome`),
  KEY `fk_MenuFisso_has_Pietanza_Pietanza1_idx` (`Pietanza_nome`),
  CONSTRAINT `fk_MenuFisso_has_Pietanza_MenuFisso1` FOREIGN KEY (`MenuFisso_nome`) REFERENCES `menufisso` (`nome`),
  CONSTRAINT `fk_MenuFisso_has_Pietanza_Pietanza1` FOREIGN KEY (`Pietanza_nome`) REFERENCES `pietanza` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ordine`
--

DROP TABLE IF EXISTS `ordine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordine` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `stato` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ordine_has_menufisso`
--

DROP TABLE IF EXISTS `ordine_has_menufisso`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordine_has_menufisso` (
  `Ordine_id` int unsigned NOT NULL,
  `MenuFisso_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`Ordine_id`,`MenuFisso_nome`),
  KEY `fk_Ordine_has_MenuFisso_Ordine1_idx` (`Ordine_id`),
  KEY `fk_Ordine_has_MenuFisso_MenuFisso1_idx` (`MenuFisso_nome`),
  CONSTRAINT `fk_Ordine_has_MenuFisso_MenuFisso1` FOREIGN KEY (`MenuFisso_nome`) REFERENCES `menufisso` (`nome`),
  CONSTRAINT `fk_Ordine_has_MenuFisso_Ordine1` FOREIGN KEY (`Ordine_id`) REFERENCES `ordine` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ordine_has_pietanza`
--

DROP TABLE IF EXISTS `ordine_has_pietanza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordine_has_pietanza` (
  `Ordine_id` int unsigned NOT NULL,
  `Pietanza_nome` varchar(45) NOT NULL,
  PRIMARY KEY (`Ordine_id`,`Pietanza_nome`),
  KEY `fk_Ordine_has_Pietanza_Ordine1_idx` (`Ordine_id`),
  KEY `fk_Ordine_has_Pietanza_Pietanza1_idx` (`Pietanza_nome`),
  CONSTRAINT `fk_Ordine_has_Pietanza_Ordine1` FOREIGN KEY (`Ordine_id`) REFERENCES `ordine` (`id`),
  CONSTRAINT `fk_Ordine_has_Pietanza_Pietanza1` FOREIGN KEY (`Pietanza_nome`) REFERENCES `pietanza` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pietanza`
--

DROP TABLE IF EXISTS `pietanza`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pietanza` (
  `nome` varchar(45) NOT NULL,
  `prezzo` decimal(5,2) unsigned NOT NULL,
  `Ricetta_id` int unsigned NOT NULL,
  PRIMARY KEY (`nome`),
  KEY `fk_Pietanza_Ricetta1_idx` (`Ricetta_id`),
  CONSTRAINT `fk_Pietanza_Ricetta1` FOREIGN KEY (`Ricetta_id`) REFERENCES `ricetta` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ricetta`
--

DROP TABLE IF EXISTS `ricetta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ricetta` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `tavolo`
--

DROP TABLE IF EXISTS `tavolo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tavolo` (
  `numero` int unsigned NOT NULL AUTO_INCREMENT,
  `postiMax` int unsigned NOT NULL,
  `Ordine_id` int unsigned DEFAULT NULL,
  `numero_coperti` int DEFAULT NULL,
  PRIMARY KEY (`numero`),
  KEY `fk_Tavolo_Ordine1_idx` (`Ordine_id`),
  CONSTRAINT `fk_Tavolo_Ordine1` FOREIGN KEY (`Ordine_id`) REFERENCES `ordine` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-07-15 13:34:06
